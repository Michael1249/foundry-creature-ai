import {profileActions} from '../framework/profile-actions.mjs';
import {profileActionFacts} from './decision-snapshot.mjs';
import {PF2eSpellcasterAdapter} from './spellcaster-adapter.mjs';
import {preparedNPCStrikes,basicMeleeStrikes} from './basic-npc-adapter.mjs';
import {chooseTacticalAction} from '../framework/tactical-behaviors.mjs';
import {preparedStrikeCandidates} from '../framework/strike-capability.mjs';
import {vampireAbility,vampireState,vampireForm,movingMist,escapingMist,retreatingMist} from '../../../pf2e-tactical-core/src/foundry/vampire-state.mjs';
import {ensureMistEscape,setVampireForm} from '../../../pf2e-tactical-conditions/src/foundry/vampire-lifecycle.mjs';
import {mistEscapeRoute,executeMistEscape} from './vampire-escape.mjs';
import {bloodEligible,ownGrab,vampireGrab,drinkBlood} from '../../../pf2e-tactical-conditions/src/foundry/vampire-blood.mjs';
import {executeNativeStrike} from './native-strikes.mjs';
import {endHostileInvisibility} from './support-spells.mjs';
import {fireShield,raiseFireShield} from '../../../pf2e-tactical-core/src/foundry/fire-shield.mjs';
const ns='foundry-creature-ai';
export const VAMPIRES={
 guardian:{id:'vampire-guardian',source:'Compendium.pf2e.blood-lords-bestiary.Actor.syFR3SChA5KCx8OA',drain:1,bloodHeal:13,killAtFive:false},
 count:{id:'vampire-count',source:'Compendium.pf2e.pathfinder-monster-core.Actor.pPQyoQHTxrE2U7px',drain:2,bloodHeal:10,killAtFive:true},
 mastermind:{id:'vampire-mastermind',source:'Compendium.pf2e.pathfinder-monster-core.Actor.TZt3H39oxVdZRKs9',drain:2,bloodHeal:10,killAtFive:true},
};
export function vampireSpec(actor){return Object.values(VAMPIRES).find(spec=>[actor.sourceId,actor._stats?.compendiumSource,actor._stats?.duplicateSource].some(s=>s===spec.source||s===spec.source.replace('.Actor.','.')))??
 VAMPIRES[actor.name?.toLowerCase().replace('vampire ','')]??null;}
export class PF2eVampireAdapter extends PF2eSpellcasterAdapter{
 get vampireSpec(){return vampireSpec(this.actor);}
 get profileId(){return this.vampireSpec.id;}
 get config(){return {...super.config,packMorale:false};}
 parts(){const base=super.parts(),form=vampireForm(this.actor),native=preparedNPCStrikes(this.actor).filter(s=>form==='bat'?/fang/i.test(s.item.name):!/bat fangs/i.test(s.item.name));
  return {...base,native,strike:native.find(s=>s.item.isMelee)??base.strike,drink:(this.actor.itemTypes.action??[]).find(a=>a.slug?.endsWith('drink-blood')),
   abilityNames:[...base.abilityNames,'Grab','Drink Blood','Change Shape','Turn to Mist','Mist Escape'],
   unsupported:base.unsupported.filter(s=>!['Grab','Drink Blood','Change Shape','Turn to Mist','Mist Escape','Dominate','Fast Healing 7','Fast Healing 10','Void Healing','Coffin Restoration','Sneak Attack','Steady Spellcasting','Untaught ranged weapon/ammunition configuration'].includes(s))};}
 async assertReady(){if(vampireForm(this.actor)==='mist'){await this.assertTurnContext();this.validateFootprint();return;}return super.assertReady();}
 async prepareTurn(options={}){await ensureMistEscape(this.token);if(vampireForm(this.actor)==='mist'){await this.assertTurnContext();return true;}return super.prepareTurn(options);}
 async snapshot(ledger,options={}){
  if(vampireForm(this.actor)==='mist'){
   const mist=vampireState(this.actor),retreat=retreatingMist(this.actor),finished=retreat&&(mist.retreat.moves>=2||game.combat.round>mist.retreat.startedRound);
   let route=movingMist(this.actor)?mistEscapeRoute(this.token):retreat&&!finished?mistEscapeRoute(this.token,{edge:mist.retreat.edge}):{revert:true,path:[]};
   if(retreat&&(finished||route.atEdge||route.blocked))route={revert:true,path:[],retreat:true};else if(retreat)route={...route,retreat:true};
   return {...ledger,self:{cell:this.originCell(),threatened:false},enemies:[],moves:[],mistEscape:route,
    diagnostics:{profileId:this.profileId,policy:retreat?'voluntary mist retreat':'mist escape',movementBlocked:route.blocked?'No legal path to a scene border was found':null}};
  }
  const state=await super.snapshot(ledger,options),parts=this.parts(),last=this.token.document.getFlag(ns,'vampireLastStrike');
  const saved=vampireState(this.actor),critical=this.actor.hitPoints.value/Math.max(1,this.actor.hitPoints.max)<=0.25;
  let retreatAvailable=false,retreatEdge=null;
  if(critical&&ledger.actionsRemaining>=2&&vampireForm(this.actor)==='vampire'&&saved.retreatUsedCombatId!==game.combat.id){
   const size=canvas.grid.size,rect=canvas.dimensions.sceneRect,positions=state.enemies.map(enemy=>enemy.awareness?.position).filter(Boolean);
   const start={x:Math.round(this.token.document.x/size),y:Math.round(this.token.document.y/size)},bounds={left:Math.ceil(rect.x/size),top:Math.ceil(rect.y/size),
    right:Math.floor((rect.x+rect.width)/size)-this.token.document.width,bottom:Math.floor((rect.y+rect.height)/size)-this.token.document.height};
   const edges=['left','right','top','bottom'].map(edge=>{const goal={x:['left','right'].includes(edge)?bounds[edge]:start.x,y:['top','bottom'].includes(edge)?bounds[edge]:start.y};
    const safety=positions.length?Math.min(...positions.map(p=>Math.max(Math.abs(goal.x*size-p.x),Math.abs(goal.y*size-p.y))/size)):0;
    return {edge,safety,distance:Math.max(Math.abs(goal.x-start.x),Math.abs(goal.y-start.y))};}).sort((a,b)=>b.safety-a.safety||a.distance-b.distance);
   let route;for(const option of edges){const possible=mistEscapeRoute(this.token,{edge:option.edge});if(possible.path.length&&!possible.blocked){route=possible;break;}}
   retreatAvailable=Boolean(route);retreatEdge=route?.edge??null;
  }
  state.vampire={...this.vampireSpec,lastStrike:last?.turn===ledger.turn?last:null,form:vampireForm(this.actor),retreatAvailable,
   retreatEdge,retreatUsedCombatId:saved.retreatUsedCombatId??null};
  for(const strike of state.strikes){const native=parts.native.find(s=>s.item.id===strike.id),linked=native?.item.linkedWeapon;
   strike.available=!linked||linked.system.equipped.carryType==='held'&&linked.system.equipped.handsHeld>=(strike.ranged?2:1);
   if(strike.ranged){strike.available&&=this.ammunition()>0;strike.rangeAversion=0.06;}
   const grab=native?.item.attackEffects?.includes?.('grab')||native?.item.system.attackEffects?.value?.includes('grab');
   if(grab)strike.onHitBenefits=[{minimumActions:2,value:5},{minimumActions:3,value:this.vampireSpec.drain*3+Math.min(6,this.actor.hitPoints.max-this.actor.hitPoints.value)}];
   if(this.profileId==='vampire-guardian')strike.precisionDamage=3.5;
  }
  for(const enemy of state.enemies){const target=this.perceivedTarget(enemy);enemy.bloodEligible=bloodEligible(target.actor);enemy.drained=target.actor.getCondition('drained')?.value??0;
   if(!enemy.bloodEligible)enemy.strikeEffectValues=Object.fromEntries(state.strikes.map(s=>[s.id,
    (s.onHitBenefits??[]).filter(b=>b.minimumActions===2&&state.actionsRemaining>=2).reduce((n,b)=>n+b.value,0)]));
   enemy.held=target.actor.hasCondition('grabbed','restrained','paralyzed','unconscious');enemy.ownGrab=Boolean(ownGrab(target.actor,this.token.id));
   if(enemy.held)enemy.offGuard=true;}
  return state;
 }
 ammunition(){return (this.actor.itemTypes.ammo??[]).filter(i=>(i.slug??i.system.slug)==='arrows').reduce((n,i)=>n+i.system.quantity,0);}
 extraCasterActions(state){return profileActions(state,profileActionFacts(this,state));}
 candidates(state){if(state.mistEscape){const r=state.mistEscape;if(r.revert)return state.actionsRemaining>0?[{id:'mist:revert',kind:'vampireForm',form:'vampire',actionCost:1,legal:true,assessment:{value:20}}]:[{id:'mist:end',kind:'endTurn',actionCost:0,legal:true,assessment:{value:0}}];
  return r.atEdge&&!r.retreat?[{id:'mist:exit',kind:'escapeScene',actionCost:0,legal:true,assessment:{value:10000}}]:r.path.length&&state.actionsRemaining>0?
  [{id:'mist:fly',kind:'mistFly',actionCost:1,legal:true,path:r.path,destination:r.path.at(-1),movementCost:r.cost,assessment:{value:10000}}]:[{id:'mist:end',kind:'endTurn',actionCost:0,legal:true,assessment:{value:0}}];}
  return super.candidates(state);}
 decide(state){if(state.mistEscape){const decision=chooseTacticalAction(this.candidates(state),{...state,behavior:null},{actionsRemaining:state.actionsRemaining});return {...decision,diagnostics:{...state.diagnostics,turnComplete:!state.mistEscape.path.length&&!state.mistEscape.atEdge}};}return super.decide(state);}
 async execute(choice,ledger,context={}){if((movingMist(this.actor)||retreatingMist(this.actor))&&['mistFly','escapeScene'].includes(choice.kind)){
  const result=await executeMistEscape(this,choice);
  if(retreatingMist(this.actor)&&choice.kind==='mistFly'&&!result.skipped){const state=vampireState(this.actor);await this.actor.setFlag(ns,'vampire',{...state,retreat:{...state.retreat,moves:(state.retreat.moves??0)+1}});}
  return result;
 }return super.execute(choice,ledger,context);}
 async executeProfileAction(choice,ledger,context={}){
  const valid=()=> (context.canContinue?.()??true)&&this.turnKey()===ledger.turn;
  if(choice.kind==='vampireForm'){
   const retreat=choice.retreat?{combatId:game.combat.id,startedRound:game.combat.round,moves:0,edge:choice.retreatEdge}:null;
   await setVampireForm(this.token,choice.form,{retreat});return {resolved:true,note:choice.retreat?'Turned to mist for an emergency withdrawal.':`Changed to ${choice.form} form.`};
  }
  if(vampireForm(this.actor)==='mist')return {resolved:true,note:'The vampire became mist; its committed offensive action cannot finish.'};
  if(choice.kind==='raiseFireShield')return raiseFireShield(this.token);
  if(['vampireEquip','vampireStow'].includes(choice.kind)){
   const interrupt=this.config.pauseForReactions!==false?await this.reactions?.action({mover:this.token,kind:'manipulate',valid,applyDamage:this.config.applyDamage})??{}:{};
   if(interrupt.pause||interrupt.endTurn)return interrupt;
   if(interrupt.disrupted||!valid()||vampireForm(this.actor)==='mist')return {resolved:true,note:'The weapon Interact was interrupted; its action remains spent.'};
   const weapon=this.actor.items.get(choice.weaponId),stow=choice.kind==='vampireStow';
   await weapon.update({'system.equipped.carryType':stow?'worn':'held','system.equipped.handsHeld':stow?0:/one-plus|two/.test(weapon.system.usage.value)?2:1});
   return {resolved:true,note:stow?'Weapon stowed with one Interact; drawing the next weapon is a separate action.':'Native weapon readied with one Interact.'};
  }
  const target=this.liveTarget(choice.targetId);
  try{
   if(choice.kind==='grab')return vampireGrab(this,target,ledger,{valid});
   if(choice.kind==='drinkBlood')return drinkBlood(this,target,{valid});
   if(choice.kind==='strike'){const strike=this.parts().native.find(s=>s.item.id===choice.strikeId);
    if(strike.item.traits.has('unarmed'))for(const w of this.actor.itemTypes.weapon??[])if(w.system.equipped?.carryType==='held'&&w.system.equipped.handsHeld===2)
     await w.update({'system.equipped.handsHeld':1}); // Release one bow hand is a free action; regripping later costs an Interact.
    if(strike.item.isRanged){const ammo=(this.actor.itemTypes.ammo??[]).find(i=>i.system.quantity>0);if(!ammo)return {skipped:true,skipReason:'No arrows remain'};await ammo.update({'system.quantity':ammo.system.quantity-1});}
    return executeNativeStrike(this,strike,target,ledger,context);}
   return await super.executeProfileAction(choice,ledger,context);
  }finally{if(['strike','grab','drinkBlood','castSpell'].includes(choice.kind)&&!['heal','ward','buff','counteract'].includes(this.parts().descriptors.find(s=>s.id===choice.spellId)?.kind))await endHostileInvisibility(this.token);}
 }
 async recordOutcome(choice,ledger,result={}){if(movingMist(this.actor)||escapingMist(this.actor))return;
  await super.recordOutcome(choice,ledger,result);if(!result.skipped){await this.token.document.setFlag(ns,'vampireLastStrike',choice.kind==='strike'?{...result.lastAction,turn:ledger.turn}:null);
   if(choice.kind!=='endTurn')await this.token.document.setFlag(ns,'vampireActions',{turn:ledger.turn});}}
}
